const details = localStorage.getItem("details").split("?");


function getResponse(){


    for(let i=0; i<details.length; i++){
        console.log(details[i]);
    }



    document.getElementById("fname").innerHTML = details[0];
    document.getElementById("lname").innerHTML = details[1];
    document.getElementById("date").innerHTML = details[2] + " / " + details[3] + " / " + details[4];
    document.getElementById("email").innerHTML = details[5];
    document.getElementById("mnumber").innerHTML = details[6];
    document.getElementById("gender").innerHTML = details[7];
    document.getElementById("city").innerHTML = details[8];
    document.getElementById("pin").innerHTML = details[9];
    document.getElementById("state").innerHTML = details[10];
    document.getElementById("address").innerHTML = details[11];
    document.getElementById("country").innerHTML = details[12];
    document.getElementById("caf").innerHTML = details[14];
    document.getElementById("x_board").innerHTML = details[15];
    document.getElementById("x_per").innerHTML = details[16];
    document.getElementById("x_yop").innerHTML = details[17];
    document.getElementById("xii_board").innerHTML = details[18];
    document.getElementById("xii_per").innerHTML = details[19];
    document.getElementById("xii_yop").innerHTML = details[20];
    document.getElementById("g_board").innerHTML = details[21];
    document.getElementById("g_per").innerHTML = details[22];
    document.getElementById("g_yop").innerHTML = details[23];
    document.getElementById("m_board").innerHTML = details[24];
    document.getElementById("m_per").innerHTML = details[25];
    document.getElementById("m_yop").innerHTML = details[26];
    for(let i=27; i<details.length; i++){
        if(details[i]=="others"){
            document.getElementById("hobbies").innerHTML += details[13];
        }else{
            document.getElementById("hobbies").innerHTML += details[i] + " ";
        }
    }
}