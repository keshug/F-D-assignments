const form1 = document.querySelector("#srf");
const btn = document.querySelector("input[type='submit']");


    
    












// let hobbies = new Array();

function getDate(){
    var ele = document.getElementById("day");
    var x = "<option value='Day' selected>Day</option>";
    ele.innerHTML = x;
    for(let i=1; i<=31; i++){
        x = x + "<option value='" + i + "'>" + i + "</option>";
        ele.innerHTML = x;
    }

    var m = document.getElementById("month");
    var n = "<option value='Month' selected>Month</option>";
    m.innerHTML = n;
    const mon = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    for(let i=1; i<=12; i++){
        n = n + "<option value='" + i + "'>" + mon[i-1] + "</option>";
        m.innerHTML = n;
    }

    var y = document.getElementById("year");
    x = "<option value='Year' selected>Year</option>";
    y.innerHTML = x;
    for(let i=1995; i<=2022; i++){
        x = x + "<option value='" + i + "'>" + i + "</option>";
        y.innerHTML = x;
    }
    
}

function validate_form(){
    

    var fname = document.forms["srf"]["fname"].value;
    var lname = document.forms["srf"]["lname"].value;
    var day = document.forms["srf"]["day"].value;
    var month = document.forms["srf"]["month"].value;
    var year = document.forms["srf"]["year"].value;
    var email = document.forms["srf"]["email"].value;
    var mnumber = document.forms["srf"]["mnumber"].value;
    var gender = document.forms["srf"]["gender"].value;
    var city = document.forms["srf"]["city"].value;
    var pin = document.forms["srf"]["pin"].value;
    var state = document.forms["srf"]["state"].value;
    var address = document.forms["srf"]["address"].value;
    var country = document.forms["srf"]["country"].value;
    var other_hobbies = document.forms["srf"]["other_hobbies"].value;
    var caf = document.forms["srf"]["caf"].value;
    var x_board = document.forms["srf"]["x_board"].value;
    var x_per = parseFloat(document.forms["srf"]["x_per"].value).toFixed(2);
    var x_yop = document.forms["srf"]["x_yop"].value;
    var xii_board = document.forms["srf"]["xii_board"].value;
    var xii_per = parseFloat(document.forms["srf"]["xii_per"].value).toFixed(2);
    var xii_yop = document.forms["srf"]["xii_yop"].value;
    var g_board = document.forms["srf"]["g_board"].value;
    var g_per = parseFloat(document.forms["srf"]["g_per"].value).toFixed(2);
    var g_yop = document.forms["srf"]["g_yop"].value;
    var m_board = document.forms["srf"]["m_board"].value;
    var m_per = parseFloat(document.forms["srf"]["m_per"].value).toFixed(2);
    var m_yop = document.forms["srf"]["m_yop"].value;
    var pattern = /[0-9]|[,./ :';"!@#$%^&*]/;
    var hobbies = document.querySelectorAll('input[type="checkbox"]:checked');
    var details = "";
    



    if(fname==""){
        alert("Please fill First Name!");
        return false;
    }
    if(fname.length>30){
        alert("Please fill less than/equal to 30 characters in First Name!");
        return false;
    }
    if(pattern.test(fname)){
        alert("Please don't fill any digit or special character in First Name!");
        return false;
    }
    if(lname==""){
        alert("Please fill Last Name!");
        return false;
    }
    if(lname.length>30){
        alert("Please fill less than/equal to 30 characters in Last Name!");
        return false;
    }
    if(pattern.test(!lname)){
        alert("Please don't fill any digit or special character in Last Name!");
        return false;
    }
    if(day=="Day"){
        alert("Please select Day!");
        return false;
    }
    if(month=="Month"){
        alert("Please select Month!");
        return false;
    }
    if(year=="Year"){
        alert("Please select Year!");
        return false;
    }
    if(email==""){
        alert("Please fill Email ID!");
        return false;
    }
    if(mnumber==""){
        alert("Please fill Mobile Number!");
        return false;
    }
    if(mnumber<1000000000 || mnumber>9999999999){
        alert("Please fill 10 digit mobile number only!");
        return false;
    }
    if(gender==""){
        alert("Please select Gender!");
        return false;
    }
    if(address==""){
        alert("Please fill Address!");
        return false;
    }
    if(city==""){
        alert("Please fill City!");
        return false;
    }
    if(city.length>30){
        alert("Please fill less than/equal to 30 characters in City!");
        return false;
    }
    if(pattern.test(!city)){
        alert("Please don't fill any digit or special character in City!");
        return false;
    }
    if(pin==""){
        alert("Please fill PIN Code!");
        return false;
    }
    if(pin<100000 || pin>999999){
        alert("Please fill 6 digit PIN Code only!");
        return false;
    }
    if(state==""){
        alert("Please fill State!");
        return false;
    }
    if(state.length>30){
        alert("Please fill less than/equal to 30 characters in State!");
        return false;
    }
    if(pattern.test(!state)){
        alert("Please don't fill any digit or special character in State!");
        return false;
    }
    if(country==""){
        alert("Please fill Country!");
        return false;
    }
    if(caf==""){
        alert("Please select Courses Applied For!");
        return false;
    }
    if(x_board==""){
        alert("Please fill class 10th Board!");
        return false;
    }
    if(x_board.length>10){
        alert("Please fill less than/equal to 10 characters in 10th board!");
        return false;
    }
    if(x_per==""){
        alert("Please fill class 10th Percentage!");
        return false;
    }else{
        if(isNaN(x_per)){
            alert("Please fill a number in class 10th Percentage!");
            return false;
        }
    }
    if(x_yop==""){
        alert("Please fill class 10th Year of Passing!");
        return false;
    }
    if(xii_board==""){
        alert("Please fill class 12th Board!");
        return false;
    }
    if(xii_board.length>10){
        alert("Please fill less than/equal to 10 characters in 12th board!");
        return false;
    }
    if(xii_per==""){
        alert("Please fill class 12th Percentage!");
        return false;
    }else{
        if(isNaN(xii_per)){
            alert("Please fill a number in class 10th Percentage!");
            return false;
        }
    }
    if(xii_yop==""){
        alert("Please fill class 12th Year of Passing!");
        return false;
    }
    if(g_board.length>10){
        alert("Please fill less than/equal to 10 characters in Graduation board!");
        return false;
    }
    if(m_board.length>10){
        alert("Please fill less than/equal to 10 characters in Masters board!");
        return false;
    }





        details += fname + "?" + lname + "?" + day + "?" + month + "?" + year + "?" + email + "?" + mnumber.toString() + "?" + gender + "?" + city + "?" + pin.toString() + "?" + state + "?" + address + "?" + country + "?" + other_hobbies + "?" + caf + "?" + x_board + "?" + x_per.toString() + "?" + x_yop.toString() + "?" + xii_board + "?" + xii_per.toString() + "?" + xii_yop.toString() + "?" + g_board + "?" + g_per.toString() + "?" + g_yop.toString() + "?" + m_board + "?" + m_per.toString() + "?" + m_yop.toString();






        for(let i=0; i<hobbies.length; i++){
            details += "?" +  hobbies[i].value;
        }


        localStorage.setItem("details", details);
}

